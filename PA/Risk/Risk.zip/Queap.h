#pragma once
#include<cstdio>
typedef int Rank;
struct Node
{
    int value;
    int count;
};
template <class T>
class Queue{    //队列的cursorlist实现
    private:
        T elem[1000000];
        Rank Next_link[1000000];
        Rank Prev_link[1000000];
        int _size = 0;
        Rank _data = -1,
             _free = 0,
             _end = -1;
    public:
        void init(int MaxContent){
            for(int i = 0; i < MaxContent; i++){
                Next_link[i] = i+1;
                Prev_link[i] = i-1;
            }
            Next_link[MaxContent - 1] = -1;
        }
        int size(){return _size;}
        bool empty(){return !_size;}
        void enqueue(T e){
            Rank k = _free;//找到空闲链表起点，准备存放元素
            if(empty()){
                _end = k;
            }
            _free = Next_link[k];//空闲链表指向下一个位置
            elem[k] = e;//存放元素
            Next_link[k] = _data;//下一个元素位置改为当前数据链表起点
            Prev_link[_data] = k;//当前数据链表起点的上一个点改为当前元素
            Prev_link[k] = -1;
            _data = k;//现在插入的点就成为数据链表起点（头）
            _size ++;//统计大小增加
            return;
        }
        T dequeue(){
            _size --;
            Rank k = _end;
            if(_data  == _end){
                _data = -1;
            }
            _end = Prev_link[k];
            Next_link[_end] = -1;
            return elem[k];
        }
        T pop(){
            _size--;
            Rank k = _data;
            _data = Next_link[k];
            Prev_link[_data] = -1;
            return elem[k];
        }
        T & roar(){
            return elem[_end];
        }
        T front(){
            return elem[_data];
        }
        void print(){
            Rank k = _data;
            while(k != -1){
                printf("%d ",elem[k]);
                k = Next_link[k];
            }
        }
};


class Queap{
    private:
        Queue<int>  q;
        Queue<Node>  pm;
    public:
        int getMax();
        void enqueue(int);
        int dequeue();
        int size(){return q.size();}
        void init(int MaxContent){
            q.init(MaxContent);
            pm.init(MaxContent);
        };
        void print(){
            q.print();
        }
};