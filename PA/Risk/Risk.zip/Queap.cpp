#include"Queap.h"

int Queap::getMax(){
    return pm.roar().value;
}

void Queap::enqueue(int e){
    q.enqueue(e);
    Node _e = {e,1};
    while(pm.front().value <= e && !pm.empty()){
        _e.count += pm.front().count;
        pm.pop();
    }
    pm.enqueue(_e);
}

int Queap::dequeue(){
    int num = pm.roar().value;
    q.dequeue();
    pm.roar().count --;
    if(pm.roar().count == 0){
        pm.dequeue();
    }
    return num;
}