#include<cstdio>
#include"Bitmap.h"

Bitmap bm[24];

void printb(int, int);
int main(){
    for(int i = 0; i < 24; i++){
        bm[i].init(2 << i);
    }
    //读入
    char c;
    int width = 0, lb = 0;
    int buffer = 0;
    while((c = getchar()) != '\n'){
        if(width < 24)
            width ++;
        else buffer %= 1<<23;
        buffer <<= 1;
        buffer += int(c - '0');
        for(int i = lb; i < width; i++){
            bm[i].set(buffer % (2<<i));
            if(bm[i].full()){
                lb ++;
            }
        }
    }
    int result = bm[lb].find();
    printb(result, lb + 1);
}

void printb(int r, int l){
    int probe = 1<<(l-1);
    for(int i = 0; i < l; i++){
        if((r & probe) == probe){
            printf("1");
        }
        else{
            printf("0");
        }
        probe >>= 1;
    }
    printf("\n");
}